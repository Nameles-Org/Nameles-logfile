# nameless-postgresql
Scripts and functions to compute the normalized entropy score in PostgreSQL (>=9.4)

## Install

1. Compile and install the entropy functions in postgres

  ```bash
  cd entropy-postgresql && make && sudo make install && cd ..
  ```
2. Create a database for the [Botlab](http://botlab.io) log files in postgres and create the entropy functions in the new database

  ```bash
  psql -f create_db.sql
  psql -d nameless -f entropy-postgresql/create_functions.sql
  ```
3. Install the python packages [psycopg2](http://initd.org/psycopg) and [tld](https://pypi.python.org/pypi/tld), used by `log_migration.py` to upload compressed log files.

## How to upload logs
```bash
./nameless-log-migration <logday> /path/to/log/files/my_log_000*.csv.gz
```
The script `log_migration.py`, when called as before, will create the following tables in the database:
  - **raw_log.log\_\<logday\>** A table with all the ad-requests in the log files
  - **log.log\_\<logday\>** Pre-processed logs table. This table is computed grouping ad-requests with the same IP, referrer, and timestamp.
  - **ip_ref\_\<logday\>** Table of tuples \<IP, referrer, count\> with the aggregate count of non-concurrent ad-requests with the same IP and referrer.
  - Temporary tables with the total number of ad-requests and normalized entropy score for the log day of both, referrers and IPs. These tables will be merged in the stats tables for IPs and referrers.
  
## How to query the database
The tables in the database can be queried as regular SQL tables. 

The referrers and SSPs domains are codified with the primary key of a lookup table. You can use [scalar subqueries](https://www.postgresql.org/docs/9.4/static/sql-expressions.html#SQL-SYNTAX-SCALAR-SUBQUERIES) to get the domain name string in the query result
```sql
SELECT
  (SELECT domain FROM lookup.domains WHERE id=referrer),
  total_151202,
  score_151202
FROM stats.referrer 
WHERE total_151202>=1000 
ORDER BY score_151202 ASC LIMIT 5;
```
Similarly, you can use [subqueries](https://www.postgresql.org/docs/9.4/static/functions-subquery.html) to filter the results by the referrer name
```sql
SELECT 
  (SELECT domain FROM lookup.domains WHERE id=referrer), 
  total_151202, 
  score_151202 
FROM stats.referrer 
WHERE referrer IN (SELECT id FROM lookup.domains WHERE domain LIKE '%.es') AND total_151202>=1000
ORDER BY score_151202 ASC LIMIT 5;
```
